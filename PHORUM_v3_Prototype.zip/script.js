
// Add interactivity to the canvas
const canvas = document.getElementById('canvas');

// Listen for drag-and-drop
canvas.addEventListener('dragover', (e) => {
  e.preventDefault();
});

canvas.addEventListener('drop', (e) => {
  e.preventDefault();

  // Create a new draggable element
  const newElement = document.createElement('div');
  newElement.className = 'draggable';
  newElement.style.left = `${e.clientX - canvas.offsetLeft}px`;
  newElement.style.top = `${e.clientY - canvas.offsetTop}px`;
  newElement.textContent = 'New Element';
  canvas.appendChild(newElement);
});

// Allow dragging for new elements
canvas.addEventListener('mousedown', (e) => {
  if (e.target.className === 'draggable') {
    const element = e.target;
    const offsetX = e.clientX - element.offsetLeft;
    const offsetY = e.clientY - element.offsetTop;

    const move = (moveEvent) => {
      element.style.left = `${moveEvent.clientX - offsetX}px`;
      element.style.top = `${moveEvent.clientY - offsetY}px`;
    };

    const stop = () => {
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', stop);
    };

    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', stop);
  }
});
