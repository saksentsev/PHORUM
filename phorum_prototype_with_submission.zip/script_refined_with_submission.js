
document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("thoughts-form");
    const feedback = document.getElementById("submission-feedback");
    
    // Form Submission Handler
    form.addEventListener("submit", (e) => {
        e.preventDefault(); // Prevent default form submission
        const inputValue = document.getElementById("thoughts-input").value;
        if (inputValue.trim()) {
            localStorage.setItem("submittedThoughts", inputValue); // Save submission
            feedback.style.display = "block";
            setTimeout(() => feedback.style.display = "none", 3000); // Hide feedback after 3s
        }
    });

    // Load saved submission if exists
    const savedSubmission = localStorage.getItem("submittedThoughts");
    if (savedSubmission) {
        document.getElementById("thoughts-input").value = savedSubmission;
    }
});
